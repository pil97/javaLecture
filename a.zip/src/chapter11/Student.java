package chapter11;

// Object 클래스.
// 최상위 클래스
// 클래스를 생성하면, 최상위 클래스인 Object클래스를 자동으로 상속받는다.
public class Student /* extends Object */ {
	int studentID;
	String studentName;
}
