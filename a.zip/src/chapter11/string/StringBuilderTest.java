package chapter11.string;

// String클래스를 사용시 성능을 목적으로 개선하기위한 클래스 StringBuilder
public class StringBuilderTest {

	public static void main(String[] args) {
		StringBuilder buffer = new StringBuilder("Java");
		buffer.append(" and");
		buffer.append(" android");
		buffer.append(" programming is fun!!!");
		
		String str = buffer.toString();
		System.out.println(str);
	

	}

}
