package chapter11.string;

// String클래스는 문자열 연결작업시 새로운 메모리가 생성이 된다.
public class StringTest2 {

	public static void main(String[] args) {

		String str = "안녕하세요.";
		
		System.out.println("처음 주소: " + System.identityHashCode(str));
		
		// str = str + "반갑습니다."; --> "안녕하세요.반갑습니다."
		str += "반갑습니다."; // 힙영역에 새기억장소가 생성이 되고, 주소가 대입된다.
		
		System.out.println("연결된 문자열 주소: " + System.identityHashCode(str));

	}

}
