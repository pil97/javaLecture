package chapter11.wrapper;

// Wrapper클래스 : 기본데이타타입을 위한 클래스
// 기본데이타 타입을 객체로 사용하는 목적.
public class IntegerTest {

	public static void main(String[] args) {
		
		// Wrapper클래스 의 종류
		// 기본데이타타입 : boolean, byte, char, short, int, long, float, double
		/*
		Boolean;
		Byte;
		Character;
		Short;
		Integer;
		Long;
		Float;
		Double;
		*/
		
		Integer num = 100;  // Boxing 형변환. 스택영역의 값 -> 힙영역의 기억장소를 생성하여, 관리
		int iNum = num.intValue();
		int jNum = 200;
		
		int sum = iNum + jNum;
		System.out.println(sum);
		
		int total = num + jNum;
		System.out.println(total);
		
		Integer i = jNum; // UnBoxing 형변환.  힙영역의 값을 스택영여의 기억장소를 생성하여, 관리.
		System.out.println(i);
		
		String str = "1000";
		// 문자열 데이타 "1000"을 숫자 1000으로 변환하여 사용.
		int number =  Integer.parseInt(str);
		
		String str2 = "true";
		//문자열 데이타 "true"를 boolean true로 변환하여 사용
		boolean b = Boolean.parseBoolean(str2);


	}

}
