package chapter11.classex;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

// String클래스의 정보를 확인
public class StringClassTest {

	public static void main(String[] args) throws ClassNotFoundException {
		
		// String클래스를 참조하는 객체.
		
		Class strClass = Class.forName("java.lang.String");
		
		// 생성자정보
		Constructor[] cons = strClass.getConstructors();
		
		for(Constructor c : cons) {
			System.out.println(c);
		}
		
		System.out.println("=================");
		// 필드정보
		Field[] fields = strClass.getFields();
		for(Field f : fields) {
			System.out.println(f);
		}
		
		// 메서드정보
		System.out.println("=================");
		Method[] methods = strClass.getMethods();
		for(Method m : methods) {
			System.out.println(m);
		}


	}

}
