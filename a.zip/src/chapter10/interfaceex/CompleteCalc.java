package chapter10.interfaceex;

// 상속시 extends : 동일한 클래스 또는 인터페이스를 상속받을 때 사용.
public class CompleteCalc extends Calculator {

	@Override
	public int times(int num1, int num2) {
		// TODO Auto-generated method stub
		return num1 * num2;
	}

	@Override
	public int divide(int num1, int num2) {
		// TODO Auto-generated method stub
		return num1 / num2;
	}

}
