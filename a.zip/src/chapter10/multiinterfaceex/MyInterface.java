package chapter10.multiinterfaceex;

// 인터페이스끼리 상속하기.
public interface MyInterface extends X, Y {

	void myMehtod();
}
