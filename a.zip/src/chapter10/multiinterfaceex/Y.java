package chapter10.multiinterfaceex;

public interface Y {

	void y();
}
