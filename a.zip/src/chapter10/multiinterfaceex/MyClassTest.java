package chapter10.multiinterfaceex;

public class MyClassTest {

	public static void main(String[] args) {
		
		MyClass mClass = new MyClass();
		
		//할아버지인터페이스와 자식클래스 객체
		X xClass = mClass;
		xClass.x();
		
		//할아버지인터페이스와 자식클래스 객체
		Y yClass = mClass;
		yClass.y();
		
		//부모인터페이스와 자식클래스 객체
		MyInterface iClass = mClass;
		iClass.myMehtod();
		iClass.x();
		iClass.y();

	}

}
