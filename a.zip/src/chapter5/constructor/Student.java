package chapter5.constructor;

public class Student {

	int studentID;
	String name;
	int age;
	String addr;
	
	// 생성자 오버로딩(overroading) : 생성자 중복정의
	// 동일한 생성자메서드를 중복해서 정의하는 문법.
	//기본생성자
	public Student() {}
	//생성자1. "홍길동"
	public Student(String pname) {
		name = pname;
	}
	//생성자2.  "홍길동", "노원구"
	public Student(String pname, String paddr) {
		name = pname;
		addr = paddr;
	}
}
