package chapter5.package1;

public class MyDate {

	//접근자를 생략시 default 로 사용
	int day;
	int month;
	int year;
}
