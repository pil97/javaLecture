package chapter5.hiding;

public class StudentTest {

	public static void main(String[] args) {
		
		Student stu1 = new Student();
//		stu1.studentName = "이순신"; 오류발생. 이유는 private 접근자로 필드가 선언되어있음.
		stu1.setStudentName("이순신");
		String name = stu1.getStudentName();
		
//		stu1.age = 200000000;

	}

}
