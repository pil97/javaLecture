package chapter5.hiding;

public class MyDateTest {

	public static void main(String[] args) {
		MyDate date = new MyDate(); //객체생성 구문
		date.month = 2;
		date.day = 31;
		date.year = 2024;

	}

}
