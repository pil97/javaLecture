package chapter5.docmall;

//회원관리 클래스
public class Member {

	//필드
	String userId;
	String passwd;
	String name;
	int age;
	String addr;
	
	//메서드
	//가입기능
	public void join() {
		
	}
	
	//수정기능
	public void modify() {
		
	}
	
	//삭제기능
	public void delete() {
		
		
	}
	
	//아이디중복체크
	public boolean idCheck() {
		
		return true;
	}
	
}
