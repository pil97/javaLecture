package chapter5.docmall;

//상품관리 클래스
public class Product {

	//필드 : 상품정보
	String p_name;
	int	p_code;
	int p_price;
	String p_desc;
	int p_qty;
	
	//메서드 : 상품을 통한 기능
	//상품등록
	public void register() {
		
	}
	
	//상품수정
	public void modify() {
		
	}
	
	//상품삭제
	public void delete() {
		
	}
}
