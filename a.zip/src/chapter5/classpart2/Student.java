package chapter5.classpart2;

// 학생정보를 관리
public class Student {

	// 필드(멤버변수)
	//학번
	int studentID;
	//이름
	String studentName;
	//학년
	int grade;
	//주소
	String address;
	
	//학생이름을 리턴하는 메서드
	public String getStudentName() {
		return studentName;
	}
}
