package chapter5.classpart;


//클래스 살펴보기 - 개요정리.

// 클래스 정의(설계)는 필드와 메서드로 구성할 수가 있다.
// 클래스는 필드(변수)로 구성
// 클래스는 메서드로 구성
// 클래스는 필드와메서드를 둘다 구성.
// 클래스는 데이타타입이다. 데이타타입기능? 기억장소를 형태와크기로 생성하는 역할
// 클래스를 사용할 때는 데이타타입처럼 사용하면 된다.
public class Student {

	//학생정보를 저장하기위한 변수  -> 필드(field)
	int studentID; // 학번
	String studentName; // 이름
	int grade;  // 학년
	String address; // 사는곳(주소지)
	
	
	//위의 변수를 이용하여, 작업하는 기능.   메서드(method).  자바스크립트 함수정의와 유사하다.
	public void showStudentInfo() {
		System.out.println(studentName + "," + address); //이름, 주소출력
	}
	
	public String getStudentName() {
		return studentName;
	}
	
	public void setStudentName(String name) {
		studentName = name;
	}
	
	
	// Student클래스안에 main메서드는 클래스의 구성요소가 아니다. 상관이 없다.
	public static void main(String[] args) {
		// 클래스 사용하기.
		Student stu1 = new Student(); // 기억장소가 생성.
		stu1.studentID = 1;
		stu1.studentName = "홍길동";
		stu1.grade = 4;
		stu1.address = "노원구";
		
		System.out.println("학번은? " + stu1.studentID);
		System.out.println("이름은? " + stu1.studentName);
		System.out.println("학년은? " + stu1.grade);
		System.out.println("주소는? " + stu1.address);
		
		//클래스 사용하기
		Student stu2 = new Student(); // 기억장소가 생성
		stu2.studentID = 2;
		stu2.studentName = "손흥민";
		stu2.grade = 3;
		stu2.address = "서대문구";
		
		System.out.println("학번은? " + stu2.studentID);
		System.out.println("이름은? " + stu2.studentName);
		System.out.println("학년은? " + stu2.grade);
		System.out.println("주소는? " + stu2.address);

	}

}
