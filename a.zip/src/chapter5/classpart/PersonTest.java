package chapter5.classpart;

public class PersonTest {

	public static void main(String[] args) {
		//Person클래스 사용 - Person객체생성
//		데이타타입 변수이름 = new 생성자메서드();
		
		Person ps1 = new Person(); //기억장소 생성
		ps1.name = "홍길동1";
		ps1.height = 180;
		ps1.weight = 75;
		ps1.gender = 'M';
		ps1.married = true;
		
		ps1.getPersonInfo();
		
		Person ps2 = new Person(); //기억장소 생성
		ps2.name = "홍길동2";
		ps2.height = 170;
		ps2.weight = 65;
		ps2.gender = 'F';
		ps2.married = false;
		
		ps2.getPersonInfo();
		
		
		Person ps3 = new Person(); // 기억장소 생성
		ps3.name = "홍길동3";
		ps3.height = 185;
		ps3.weight = 70;
		ps3.gender = 'F';
		ps3.married = true;
		
		ps3.getPersonInfo();

	}

}
