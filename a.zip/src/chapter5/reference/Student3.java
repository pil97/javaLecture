package chapter5.reference;

public class Student3 {
	
	int studentID;
	String studentName;
	
	// 필드가 클래스로 선언되면, 초기값은 null 로 된다.
	Subject korean;
	Subject math;
	
	public Student3() {
		// 중요. 주석을 체크해서 실행.
		korean = new Subject();
		math = new Subject();
	}
	
	public void setKorean(String name, int score) {
		korean.subjectName = name;
		korean.scorePoint = score;
	}
	
	public void setMath(String name, int score) {
		math.subjectName = name;
		math.scorePoint = score;
	}
}
