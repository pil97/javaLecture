package chapter5.reference;

//과목
public class Subject {

	String subjectName; //과목이름
	int scorePoint; // 과목점수
}
