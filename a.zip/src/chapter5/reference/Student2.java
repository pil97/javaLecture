package chapter5.reference;

public class Student2 {
	
	int studentID; //학번
	String stduentName; // 학생이름
	
	
	int koreaScore; // 국어점수
	int mathScore;  // 수학점수
	
	String koreaSubject; //국어과목
	String mathSubject; // 수학과목
}
