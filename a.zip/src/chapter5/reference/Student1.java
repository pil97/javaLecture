package chapter5.reference;

public class Student1 {
	
	int studentID; //학번
	String stduentName; // 학생이름
	int koreaScore; // 국어점수
	int mathScore;  // 수학점수
}
