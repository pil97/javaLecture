package chapter7.basic;

public class Person {

	int a;
	int b;
}
