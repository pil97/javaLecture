package chapter7.array;

// 알파벳을 역순으로 출력
public class CharArrayReverse {

	public static void main(String[] args) {
		char[] alpahabets = new char[26];
		char ch = 'Z'; // 
		
		for(int i=0; i<alpahabets.length; i++, ch--) {
			alpahabets[i] = ch; // i=0 일 경우 90가 저장
		}
		
		for(int i=0; i<alpahabets.length; i++) {
			System.out.println(alpahabets[i] + "," + (int) alpahabets[i]);
		}

	}

}
