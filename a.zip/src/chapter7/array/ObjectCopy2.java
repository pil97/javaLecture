package chapter7.array;

// 얕은복사 예제 - 주소만 복사
// 메모리가 복사되면서, 메모리의 일부중에 주소만 복사.
public class ObjectCopy2 {

	public static void main(String[] args) {
		Book[] bookArray1 = new Book[3]; // 객체배열. 원본
		Book[] bookArray2 = new Book[3]; // 객체배열. 사본
		
		// 힙영역에 실제데이터가 생성되는 기억장소가 생성.
		// bookArray1 배열에 데이타작업. bookArray2 배열은 기본값
		bookArray1[0] = new Book("택백산맥", "조정래");
		bookArray1[1] = new Book("데미안", "헤르만 헤세");
		bookArray1[2] = new Book("어떻게 살 것인가", "유시민");
		
		
		// bookArray2 배열은 System.arraycopy() 작업이 되기전까지
		// 실제 데이터를 저장하는 힙영역의 기억장소는 생성전이다.
		
		// bookArray1배열에서 bookArray2배열로 3개의 데이타가 복사.
		// 기본데이타타입은 값이 복사
		// 참조타입은 주소만 복사
 		System.arraycopy(bookArray1, 0, bookArray2, 0, 3);
		
		// 복사된 배열의 데이타를 출력
 		System.out.println("=== bookArray2 ===");
 		for(int i=0; i<bookArray2.length; i++){
			bookArray2[i].showBookInfo();
		}
		
 		// 원본배열에 데이터 변경작업을 하게되면, 
 		// bookArray2의 참조타입 멤버들은 bookArray1 참조타입 멤버들의 주소가 동일하기 때문에
 		// bookArray1, bookArray2로 참조타입 멤버의 값을 변경하게되면,
 		// 항상 같을수 밖에 없다.
		bookArray1[0].setBookName("나목");
		bookArray1[0].setAuthor("박완서");
		
		// 원본배열 출력
		System.out.println("=== bookArray1 ===");
		for(int i=0; i<bookArray1.length; i++){
			bookArray1[i].showBookInfo();
		}
		
		// 사본배열 출력
		System.out.println("=== bookArray2 ===");
		for(int i=0; i<bookArray2.length; i++){
			bookArray2[i].showBookInfo();
		}
	}
}
