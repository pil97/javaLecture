package chapter7.array;

public class ArrayTest2 {

	public static void main(String[] args) {
		// 참조타입은 기본값이 null로 초기화된다.
		// 배열 기본값이 null 로 초기화된다.
		double[] data = new double[5]; // 힙영역에 생성된 기억장소의 초기값은 0.0
		
		// 값을 변경.
		data[0] = 10.0;
		data[1] = 20.0;
		data[2] = 30.0;
		
		// data.length : 배열의 길이. 5 힙영역에 생성된 배열기억장소 요소의 개수
		for(int i=0; i<data.length; i++) {
			System.out.println(data[i]);
		}

	}

}
