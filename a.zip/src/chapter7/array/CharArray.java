package chapter7.array;

// 문자저장 배열
public class CharArray {

	public static void main(String[] args) {
		char[] alpahabets = new char[26];
		char ch = 'A'; // 65.   소문자 : 97
		
		for(int i=0; i<alpahabets.length; i++, ch++) {
			alpahabets[i] = ch; // i=0 일 경우 65가 저장
		}
		
		for(int i=0; i<alpahabets.length; i++) {
			System.out.println(alpahabets[i] + "," + (int) alpahabets[i]);
		}

	}

}
