package chapter7.array;

// 다차원배열 : 2차원배열
public class TwoDimension {

	public static void main(String[] args) {
		// 2*3 : 2행3열
		int[][] arr = {
						{1, 2, 3},   // 첫번째 행 arr[0]  arr[0][0], arr[0][1], arr[0][2] 
						{4, 5, 6}    // 두번째 행 arr[1]  arr[1][0], arr[1][1], arr[1][2]
					  };
		
		// 2차원배열 출력
		// arr.length : 2.  몇행?
		for(int i=0; i<arr.length; i++) {  // 행
			for(int j=0; j<arr[i].length; j++) {  // 열
				System.out.println(arr[i][j]);
			}
			System.out.println();
		}
		
		
		System.out.println("arr 은 몇행? " + arr.length);
		System.out.println("첫번째 행은 열의 몇개? " + arr[0].length);
		System.out.println("두번째 행은 열의 몇개? " + arr[1].length);
		 
		System.out.println(arr[0][1]);
		System.out.println(arr[1][2]);
	}

}
