package chapter6.thisex;

// 하나의 파일안에서 클래스가 여러개 존재 할 경우 public 은 1개이어야 한다.
// 그 클래스는 파일명과 같아야 한다.

// 하나의 파일안에 클래스가 여러개 선언되어 있어도, 컴파일에 의하여 클래스파일은 각각 생성된다.


// this : BirthDay클래스로 생성될 힙영역의 메모리. 즉 인스턴스를 가리키는 의미이다.
class BirthDay {

	int day;
	int month;
	int year;
	
	// year필드를 위한 setter메서드
	public void setYear(int year) {
		this.year = year;
	}
	
	public void printThis() {
		System.out.println(this); // this 출력확인.
	}
}

public class BirthDayTest {

	public static void main(String[] args) {
		BirthDay bDay = new BirthDay();
		bDay.setYear(2024);
		
		System.out.println(bDay); // chapter6.thisex.BirthDay@7c30a502
		bDay.printThis(); // chapter6.thisex.BirthDay@7c30a502

	}

}


