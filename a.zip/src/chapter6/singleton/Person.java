package chapter6.singleton;

// 일반클래스 : 보통 여러개의 객체(인스턴스)를 생성하는 목적.
public class Person {

	String ssn;
	String name;
	int age;
	String addr;
}
