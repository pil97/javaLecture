package chapter6.singleton;

public class PersonTest {

	public static void main(String[] args) {
		// 여러개의 객체(인스턴스)를 생성하는 목적.
		Person p1 = new Person();
		
		Person p2 = new Person();
		
		Person p3 = new Person();

	}

}
