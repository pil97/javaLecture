package chapter6.singleton;

// 디자인 패턴 : 싱글톤 패턴예제.
// 일반적인 클래스 : 클래스를 통하여 객체를 계속 생성 할수가 있다.
// 싱글톤 클래스 : 단 하나의 객체만 생성이 가능. 생성된 객체를 참조하는 형태.
public class Company {

	// 클래스 안에서 자신을 private static멤버로 객체를 생성.
	private static Company instance = new Company();
	
	//생성자
	private Company() {}
	
	//public getter메서드 정의
	public static Company getInstance() {
		if(instance == null) {
			instance = new Company();
		}
		return instance;
	}
}
