package chapter6.singleton;

import java.util.Calendar;

public class CompanyTest {

	public static void main(String[] args) {
		//객체를 생성
		Company com1 = Company.getInstance();
		Company com2 = Company.getInstance();
		
		// com1과 com2는 동일한 객체를 참조.
		System.out.println(com1 == com2); // true
		
		// jdk 날짜 관련클래스
		Calendar cal = Calendar.getInstance();


	}

}
