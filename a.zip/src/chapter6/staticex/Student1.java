package chapter6.staticex;

public class Student1 {

	//필드선언(멤버변수)
	// [접근자] [static] 데이타타입 변수이름;
	
	
	// 정적필드(static) or non-instance 필드 : 메모리가 static area(method area)
	// 객체생성보다 먼저 기억장소가 생성이된다.
	static int serialNum; 
	
	// (instance) 인스턴스 필드 : 메모리가 힙(heap) 영역에 생성된다.
	int studentId;
	String studentName;
	int grade;
	String address;
	
	// studentName필드에 값을 읽어오는 메서드 : Getter
	public String getStudentName() {
		return studentName;
	}
	// studentName필드에 값을 저장하는 메서드 : Setter
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	
	// static serialNum필드에 값을 읽어오는 메서드 : Getter
	public static int getSerialNum() {
		int i = 10;
	
		// static메서드안에서 객체생성이 될지 안될지 알수가 없으므로
		// 인스턴스 메서드 또는 필드를 사용하지 못하도록 문법으로 설계를 해두었다.
//		studentName = "홍길동";
		
		return serialNum;
	}
	
	// static serialNum필드에 값을 저장하는 메서드 : Setter
	public static void setSerialNum(int serialNum) {
		Student1.serialNum = serialNum;
	}
	
	
}
