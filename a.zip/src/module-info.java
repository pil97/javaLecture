/**
 * 
 */
/**
 * 
 */
module study {
}