package chapter12.collection.treeset;

import java.util.TreeSet;

// Set인터페이스를 구현한 TreeSet클래스
// 기본 데이타에 대하여 이진트리구조 관리로 정렬을 지원.
// 객체는 정렬기준이 없어서, Comparable인터페이스를 구현해야 객체정렬작업을 할수가 있다.
public class TreeSetTest {

	public static void main(String[] args) {
		TreeSet<String> treeSet = new TreeSet<String>();
		treeSet.add("홍길동");
		treeSet.add("강감찬");
		treeSet.add("이순신");
		
		for(String str : treeSet) {
			System.out.println(str);
		}

	}

}
