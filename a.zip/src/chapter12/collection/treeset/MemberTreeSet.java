package chapter12.collection.treeset;

import java.util.Iterator;
import java.util.TreeSet;


public class MemberTreeSet {

	private TreeSet<Member> treeSet;

	public MemberTreeSet() {
//		super();
		treeSet = new TreeSet<Member>();
	}
	
	// member 추가
	public void addMember(Member member) {
		// add메서드가 호출될 때 중복검사가 발생된다.
		// hashCode(), equals()메서드가 동작이 되어, 결과값을 가지고 중복처리를 한다.
		treeSet.add(member);
	}
	
	// 멤버id가 존재하면, 삭제
	public boolean removeMember(int memberId) {
		
		// 삭제 : Iterator이용
		//Iterator(반복자)를 사용하여 데이터 읽기
		Iterator<Member> ir =treeSet.iterator();
		while(ir.hasNext()) { // 커서가 가리키는 위치에 데이타 존재유무를 체크
			Member member = ir.next(); // 데이터를 읽어온다.
			int tempId = member.getMemberId();
			if(tempId == memberId) {
				treeSet.remove(member); // 멤버를 객체로 삭제.
				return true;
			}
		}
		
		
		
		System.out.println(memberId + "가 존재하지 않습니다.");
		return false;
	}
	
	// 전체목록보기
	public void showAllMember() {
		//향상된 for문
		for(Member member : treeSet) {
			System.out.println(member);
		}
	}

	
	
	
}
