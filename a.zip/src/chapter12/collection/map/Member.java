package chapter12.collection.map;

// Comparable<Member> : 객체는 정렬에 대한 기준이 없다.
// 객체를 정렬할 경우에는 Comparable인터페이스를 구현해야 한다.
public class Member implements Comparable<Member>{

	private int memberId;        //ȸ�� ���̵�
	private String memberName;   //ȸ�� �̸�

	public Member(int memberId, String memberName){ //������
		this.memberId = memberId;
		this.memberName = memberName;
	}
	
	public int getMemberId() {  //
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	
	@Override
	public String toString(){   //toString �޼ҵ� �����ε�
		return memberName + " 회원님의 아이디는 " + memberId + "입니다.";
	}

	// 중복검사 기준.
	// Member클래스에 동일한 학번데이타가 사용시 중복검사 의하여, 저장되지 않는다. 
	@Override
	public int hashCode() {
		System.out.println("중복검사 hashCode()");
		return memberId;
	}

	@Override
	public boolean equals(Object obj) {
		System.out.println("중복검사 equals()");
		if( obj instanceof Member){
			Member member = (Member)obj;
			if( this.memberId == member.memberId ) // 학번이 동일한 경우
				return true;
			else 
				return false;
		}
		return false;
	}
	
	// 학번으로 정렬작업을 한 재정의.
	@Override
	public int compareTo(Member member) {
		
		// 기존학번 - 신규추가학번 차이를 1, 0, -1 결과값으로 하여, 객체를 정렬
		return (this.memberId - member.memberId);   // 1, 0, -1 오름차순
//		return (this.memberId - member.memberId) *  (-1);   // -1 0 1 내림차순
	}
	
}
