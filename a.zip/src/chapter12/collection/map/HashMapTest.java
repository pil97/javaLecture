package chapter12.collection.map;

import java.util.HashMap;

// map인터페이스를 구현한 HashMap클래스
// 자료구조를 키(Key) 와 값(Value)의 쌍구조로 관리
// 키는 중복불가능 값은 중복허용.
public class HashMapTest {

	public static void main(String[] args) {

		HashMap<String, String> map = new HashMap<String, String>();
		
		map.put("1", "홍길동1");
		map.put("2", "홍길동2");
		map.put("3", "홍길동3");
		map.put("4", "홍길동4");
		
		map.put("2", "홍길동4");
		
		System.out.println(map);
		
		
	}

}
