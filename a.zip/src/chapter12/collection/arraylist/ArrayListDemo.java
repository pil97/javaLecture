package chapter12.collection.arraylist;

import java.util.ArrayList;

import chapter12.collection.Member;

// 컬렉션? 객체를 저장및관리하는 목적.
// ArrayList클래스 사용법.

public class ArrayListDemo {

	public static void main(String[] args) {
		
		ArrayList<Member> al = new ArrayList<Member>();
		
		//데이터 추가.  add()
		al.add(new Member(1, "손흥민")); // 인덱스 0
		al.add(new Member(2, "김민재")); // 인덱스 1
		al.add(new Member(3, "황희찬")); // 인덱스 2
		al.add(new Member(4, "이강인")); // 인덱스 3
		
		
		// 모든데이터 읽기. get(인덱스)
		for(int i=0; i<al.size(); i++) {
			System.out.println(al.get(i));
		}
		
		System.out.println("======================================");
		
		// 제거.  remove(인덱스)
		al.remove(2); // 3번째 데이타제거.  al.add(new Member(3, "황희찬"));
		
		// 모든 데이터 읽기. get(인덱스)
		for(int i=0; i<al.size(); i++) {
			System.out.println(al.get(i));
		}
		
		System.out.println("======================================");
		
		Member memberSon = al.get(0);
		System.out.println(memberSon); // memberSon.toString() 호출

	}

}
