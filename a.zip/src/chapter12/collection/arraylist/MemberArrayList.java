package chapter12.collection.arraylist;

import java.util.ArrayList;
import java.util.Iterator;

import chapter12.collection.Member;

// Collection인터페이스 - List인터페이스
// List인터페이스 특징? 저장순서를 유지(인덱싱방식). 값중복 허용.
// ArrayList클래스 : List인터페이스를 구현
// 컬렉션클래스의 목적? 객체저장및 관리하는 목적

public class MemberArrayList {

	private ArrayList<Member> arrayList;

	public MemberArrayList() {
//		super();
		arrayList = new ArrayList<Member>();
	}
	
	// member 추가
	public void addMember(Member member) {
		arrayList.add(member);
	}
	
	// 멤버id가 존재하면, 삭제
	public boolean removeMember(int memberId) {
		
		// 삭제1 : for문이용
		for(int i=0; i<arrayList.size(); i++) {
			Member member = arrayList.get(i);
			int tempId = member.getMemberId();
			if(tempId == memberId) { // 멤버아이디가 일치되는 데이타
				arrayList.remove(i); // 멤버를 인덱스로 삭제
				return true;
			}
		}
		
		// 삭제2 : Iterator이용
		//Iterator(반복자)를 사용하여 데이터 읽기
		Iterator<Member> ir =arrayList.iterator();
		while(ir.hasNext()) { // 커서가 가리키는 위치에 데이타 존재유무를 체크
			Member member = ir.next(); // 데이터를 읽어온다.
			int tempId = member.getMemberId();
			if(tempId == memberId) {
				arrayList.remove(member); // 멤버를 객체로 삭제.
				return true;
			}
		}
		
		
		
		System.out.println(memberId + "가 존재하지 않습니다.");
		return false;
	}
	
	// 전체목록보기
	public void showAllMember() {
		//향상된 for문
		for(Member member : arrayList) {
			System.out.println(member);
		}
	}

	
	
	
}
