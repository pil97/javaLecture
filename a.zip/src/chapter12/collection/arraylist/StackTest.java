package chapter12.collection.arraylist;

import java.util.Stack;

// List인터페이스 구현 : Stack클래스
// 자료구조특징? LIFO(Last Input First Output)
// 예>브라우저 뒤로/앞으로 기능

public class StackTest {

	public static void main(String[] args) {
		
		Stack<String> stack = new Stack<String>();
		
		// 데이타추가 push
		stack.push("A");
		stack.push("B");
		stack.push("C");
		stack.push("D");
		
		int size = stack.size();
		
		// D C B A
		for(int i=0; i<size; i++) {
			System.out.println(stack.pop()); // 데이터 꺼내오기.
		}

	}

}
