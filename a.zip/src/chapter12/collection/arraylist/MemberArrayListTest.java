package chapter12.collection.arraylist;

import chapter12.collection.Member;

public class MemberArrayListTest {

	public static void main(String[] args) {
		MemberArrayList memberArrayList = new MemberArrayList();
		
		Member mem1 = new Member(1001, "홍길동1");
		Member mem2 = new Member(1002, "홍길동2");
		Member mem3 = new Member(1003, "홍길동3");
		Member mem4 = new Member(1004, "홍길동4");
		
		memberArrayList.addMember(mem1);
		memberArrayList.addMember(mem2);
		memberArrayList.addMember(mem3);
		memberArrayList.addMember(mem4);
		
		memberArrayList.showAllMember();
		memberArrayList.removeMember(mem1.getMemberId());
		memberArrayList.showAllMember();

	}

}
