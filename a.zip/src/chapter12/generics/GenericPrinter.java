package chapter12.generics;

// 제네릭기능이 있는 GenericPrinter클래스
// class 클래스명<알파벳문자>           <T> : 타입파라미터.  T에는 참조타입만 사용가능.
public class GenericPrinter<T extends Material> {

	private T material;

	public T getMaterial() {
		return material;
	}

	public void setMaterial(T material) {
		this.material = material;
	}
	
	public String toString() {
		return material.toString();
	}
	
	public void printing() {
		material.doPrinting();
	}
}
