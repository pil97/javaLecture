package chapter12.generics;

public abstract class Material {

	public abstract void doPrinting();
}
