package chapter2;

public class CharacterEx3 {
	
	// main메서드
	public static void main(String[] args) {
		// char데이터타입 값범위 0 ~ 65535
		
		// int형 변수를 char데이타타입 형변환해서 사용하는 예제.
		// int형 값이 0 ~ 65535 범위내에 사용되고 있을 때 char형변환하여, 정상적으로 사용이가능.
		
		int a = 65;
		int b = -66;
		
		char a2 = 65; // 문자로 사용
//		char b2 = -66;   에러발생 값의 범위이내에 해당하지 않음.
		
		// 데이타타입변환 또는 형변환 또는 Casting
		// (데이타타입) 변수
		System.out.println((char)a);
		System.out.println((char)b);
		System.out.println((char)a2);
	}
	
	
}
