package chapter2;

public class OverflowEX {

	public static void main(String[] args) {
		// int형 : -2,147,483,648 to 2,147,483,647   10자리
		// 자바에서는 숫자를 사용하면, int형 데이타로 기본인식한다.
		// 값의 범위가 int범위보다 크면 에러가 발생되어, 값에 뒤에 접미사 L or l 을 붙이면
		// long형 데이타로 사용할 수가 있다.
		
		
		//int num1 = 12345678900;  // 값이 int형범위를 벗어남. 11자리
		long num2 = 12345678900L; // 

	}

}
