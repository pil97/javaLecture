package chapter2;

public class IntegerVariable1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 정수값을 사용시 데이타타입은 int형을 기본으로 한다.
		int iVal_1 = 10;
		int iVal_2 = 20;
		
		int result = iVal_1 + iVal_2;
		
		System.out.println(result);
		
		
	}

}
