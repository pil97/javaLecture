package chapter2;

public class DoubleEx2 {

	public static void main(String[] args) {
		// 부동소수점 표현방식에 따른 실수값 오차 예제
		double dnum = 1;
		
		for(int i=0; i<10000; i++) {
			dnum = dnum + 0.1;
		}
		System.out.println(dnum); // 1001.000000000159

	}

}
