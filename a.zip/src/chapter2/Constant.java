package chapter2;

public class Constant {

	public static void main(String[] args) {
		// 상수 선언하기. 상수이름을 대문자로 사용한다.(관례)  
		// 변수와 의미가 다르다. 차이점을 공부해야 한다.
		
		final int MAX_NUM = 100; // 상수
//		int MAX_NUM = 100;  변수
		
//		MAX_NUM = 1000;  상수명에 값을 변경하는 경우는 에러발생.
		
		final int MIN_NUM;
		
		MIN_NUM = 0;
		
		System.out.println(MAX_NUM);
		System.out.println(MIN_NUM);

	}

}
