package chapter2;

public class IntegerVariable {

	public static void main(String[] args) {
		// 중요.
		// 변수끼리 연산이 발생되면, 변수의 크기가 int형보다 작은 데이타타입이면, 
		// int 데이타타입으로 형변환이 발생된다.
		
		// 일반적인 작업에서 정수형 데이타를 사용시 기억장소는 int or long 을 사용한다.
		// byte, short 데이터타입은 거의 사용안한다.
		// byte는 가끔 특정한 작업시 사용함.
		
		// CTRL+SpaceBar
		
		//정수 데이타타입 : byte(1) < short(2) < int(4) 기준 < long(8).    번외>char
		
		short sVal = 10;
		byte bVal = 20;
		// sVal변수가 int형변환, bVal변수가 int형변환.   short + byte -> int + int = int결과
		System.out.println( sVal + bVal);  

	}

}
