package chapter2;

public class CharacterEx2 {

	public static void main(String[] args) {
		// char데이타타입(2byte) : 정수형. 문자 1개를 저장하는 기억장소 생성.
		// 1개의 문자를 표현시 반드시 ' '  작은따옴표를 감싸야 한다.
		// 실제 기억장소에는 코드(ascii code, uni-code)값으로 저장됨.
		
		char ch1 = '한';
		char ch2 = '\uD55C'; // \\u 유니코드 D55C 16진수값
		char ch3 = 65;
		
		System.out.println(ch1);
		System.out.println(ch2);
		System.out.println(ch3);

	}

}
