package chapter2;

public class Variable1 {

	public static void main(String[] args) {
		// 변수 : 기억장소를 가리키는 이름.
		// 데이터타입(자료형)
		
		/*
		 자바스크립트 변수선언
		var 변수;
		let 변수;
		const 변수;
		*/
		
		// 변수선언
		// 데이타타입 변수이름;
		// 데이타타입 기능? 메모리상에 기억장소를 크기와형태라는 2가지를 이용하여 생성
		// 크기 : 1바이트, 2바이트, 4바이트, 8바이트
		// 형태: 정수형, 실수형, 논리형, 문자형 .....
		
		//int level;  // 변수선언(정의)
		//level = 10;
		
		int level = 10;
		
		// System.out.println() - ()안에 데이타 또는 변수의 값을 출력하는 기능.
		System.out.println(level);
		
		

	}

}
