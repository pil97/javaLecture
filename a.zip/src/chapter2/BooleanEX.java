package chapter2;

public class BooleanEX {

	public static void main(String[] args) {
		// 논리형 데이타타입.  true or false 값 사용.
		
		boolean isMarried = true;
		System.out.println();

	}

}
