package chapter2;

public class ByteVariable {

	public static void main(String[] args) {
		// byte데이타타입 - 1)정수형 2)크기:1byte 3)범위:-128 to 127
		byte bs1 = -128;
//		byte bs2 = 128;  값의 범위가 초과되어 에러발생.
		System.out.println(bs1);

	}

}
