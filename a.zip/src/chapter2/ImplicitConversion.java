package chapter2;

public class ImplicitConversion {

	public static void main(String[] args) {
		// 형변환(Casting) : 타입일치
		// 정수형 데이타타입보다는 실수형데이타타입이 더 큰 개념이다.
		// byte < short or char < int < long < float < double
		// 묵시적 형변환 
		// -> 내부적으로는 좌측변수 데이타타입에 우측의 데이타값이 좌측의 변수 타입으로변환되어 값이 저장된다.
		
		// 큰 데이타타입 변수 = 작은데이타타입의 값
		byte bNum = 10;
		int iNum = bNum; //  int = byte;   int iNum = (int) bNum;
		
		System.out.println(bNum);
		System.out.println(iNum);
		
		
		int iNum2 = 20;
		float fNum = iNum2;// float = int;  float fNum = (float) iNum2;
		
		System.out.println(iNum);
		System.out.println(fNum);
		
		// 다른 데이타타입끼리 연산을 하면, 큰데이타타입으로 형변환이 발생된다.
		double dNum;
		dNum = fNum + iNum;  //    dNum = fNum + (float)iNum  -> dNum = (double)(fNum + (float)iNum)
		System.out.println(dNum);

	}

}
