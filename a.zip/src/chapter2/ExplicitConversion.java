package chapter2;

public class ExplicitConversion {

	public static void main(String[] args) {
		// 명시적 형변환 예제.
		// 좌측의 데이타타입이 우측의 데이타값보다 클 경우 명시적형변환 작업을 해야한다.
		// 형변환 작업시 값이 다르게 나오는것을 주의해야 한다.
		
		// 변수 = (데이타타입) 변수  타입일치가 되게 한다.
		
		double dNum1 = 1.2;
		float fNum2 = 0.9f;
		
		int iNum3 = (int)dNum1 + (int)fNum2;
		int iNum4 = (int)(dNum1 + fNum2);
		
		System.out.println(iNum3);
		System.out.println(iNum4);

	}

}
