package chapter2;

public class DoubleEx1 {

	public static void main(String[] args) {
		// 실수형 데이타타입 - 정수형데이타타입 표현방식을 사용하지 않고, 부동소수점 표현방식으로 실수값을 표현.
		// float(4), double(8) 기준.
		
		// 실수값을 사용하면 double데이타타입으로 처리된다.
		
		double dnum = 3.14; // double 데이터타입
		float fnum = 3.14F;
		
		System.out.println(dnum);
		System.out.println(fnum);
		

	}

}
