package chapter2;

public class TypeInference {

	public static void main(String[] args) {
		// 데이타타입없이 변수 선언하기. java 10
		
		int i = 10;
		var j = 10.0; // double j = 10.0 컴파일 됨.  TypeInference.class 파일생성
		var str = "hello"; // String str = "hello"; 컴파일 됨.
		
		System.out.println(i);
		System.out.println(j);
		System.out.println(str);
	}

}
