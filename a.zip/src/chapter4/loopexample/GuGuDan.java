package chapter4.loopexample;

public class GuGuDan {

	public static void main(String[] args) {
		// 중첩for문을 이용한 구구단 예제.
		/*
		 첫번째 for문 : 곱의 기능
		 두번재 for문 : 단의 기능 
		 */
		
		
		for(int i=1; i<=9; i++) {
			for(int j=2; j<=9; j++) {
				System.out.print(j + "*" + i + "=" + (j*i) + "\t");
			}
			System.out.println();
		}

	}

}
