package chapter4.ifexample;

public class SwitchCase2 {

	public static void main(String[] args) {
		// 선택문 : switch
		
		//String 클래스 : 문자열 데이타를 저장할 때 사용.
		// 데이터 표현 :  "홍길동" 큰따옴표로 감싸야 한다.
		String medal = "Gold";  // Gold, Silver, Bronze, 기타값
		

		switch(medal) {
			case "Gold":
				System.out.println("금메달입니다.");
				break;
			case "Silver":
				System.out.println("은메달입니다.");
				break;
			case "Bronze":
				break;
			default:
				System.out.println("메달이 없습니다.");
				break;
		}
		
		

	}

}
