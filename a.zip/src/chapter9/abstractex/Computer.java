package chapter9.abstractex;

// 추상클래스
// 일반메서드와 추상메서드를 둘다 구성해서 만들수 있다.
// 상속을 목적으로 한다.
// 객체를 생성 할 수가 없다.  예>  Computer computer = new Computer(); 에러
public abstract class Computer {

	// 추상메서드 : 중앙정부의 세부내용이 없는 정책. 예>출산정책
	public abstract void display();
	public abstract void typing();
	
	//일반메서드 : 중앙정부의 세부내용이 있는 정책. 예>교통정책
	public void turnOn() {
		System.out.println("전원을 켭니다.");
	}
	public void turnOff() {
		System.out.println("전원을 끕니다.");
	}
}
