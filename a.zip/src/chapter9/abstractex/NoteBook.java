package chapter9.abstractex;

// Computer 추상클래스의 추상메서드 모두 자식클래스에서 구현해야 한다.
// 만약에 하나라도 구현하지 않으면 자기자신의 추상클래스가 된다.
public abstract class NoteBook extends Computer {

	@Override
	public void display() {
		System.out.println("NoteBook Display");
		
	}

	
}
