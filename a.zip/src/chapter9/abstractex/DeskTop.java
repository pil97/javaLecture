package chapter9.abstractex;

// 추상클래스를 상속받는 자식클래스는 추상클래스의 추상메서드를 반드시 구현(재정의) 해야한다는 문법규칙.
public class DeskTop extends Computer {

	@Override
	public void display() {
		System.out.println("DeskTop Display");
		
	}

	@Override
	public void typing() {
		System.out.println("DeskTop Typing");
		
	}

}
