package chapter9.finalex;

// final 키워드 미사용시 클래스는 상속이 가능하다.
public class Parent {
	
}

class Child extends Parent {
	
}

// final 키워드 사용시 클래스는 상속이 불가능하다.
final class TestA {
	
}


// TestA클래스가 final이므로 상속불가.
/*
class TestB extends TestA {
	
}
*/

