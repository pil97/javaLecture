package chapter15.stream.decorator;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

// 보조스트림 : 메인스트림에 추가하여 작업하는 특징을 갖고있다.
//  데코레이터 디자인패턴 특징.
public class InputStreamReaderTest {

	public static void main(String[] args) {
		
		// 메인스트림.(1차스트림)
//		FileInputStream fis = new FileInputStream("reader.txt");
		
		// 보조스트림. (2차스트림)
		// InputStreamReader : 바이트 단위스트림을 문자 단위스트림을 변환하는 기능
		try(InputStreamReader isr = new InputStreamReader(new FileInputStream("reader.txt"))) {
			int i;
			while( (i = isr.read()) != -1) {
				System.out.print((char)i);
			}
		}catch(IOException e) {
			e.printStackTrace();
		}

	}

}
