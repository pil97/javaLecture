package chapter15.stream.decorator;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

// 보조스트림이 버퍼스트림을 사용 안함.
public class NonBufferedStreamTest {

	public static void main(String[] args) {

		long milisecond = 0;
		try(
			// 메인스트림 객체생성
			FileInputStream fis = new FileInputStream("a.zip");
			FileOutputStream fos = new FileOutputStream("copy.zip");
			
			) 
		{
			// 버퍼스트림을 이용하여 작업하기전 시간체크.
			milisecond = System.currentTimeMillis();
			
			int i;
			while( (i = fis.read()) != -1) {
				fos.write(i);
			}
			
			// 버퍼스트림을 이용하여 작업완료 후 시간체크.
			milisecond = System.currentTimeMillis() - milisecond;
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("파일 복사시간 " + milisecond + " milisecond 소요됨.");

	}

}
