package chapter15.stream.other;

import java.io.File;
import java.io.IOException;

// 파일과 폴더관련기능을 제공하는 클래스 : File클래스

public class FileTest {

	public static void main(String[] args) throws IOException {
		
		File file = new File("C:\\Dev\\workspace\\java_basic\\study\\src\\chapter15\\stream\\other\\newFile.txt");
		file.createNewFile();
		
		System.out.println(file.isFile()); // true file객체가 참조하는 대상이 파일인지 체크.
		System.out.println(file.isDirectory());// false file객체가 참조하는 대상이 폴더인지 체크.
		System.out.println(file.getName()); // newFile.txt
		System.out.println(file.getAbsolutePath()); // C:\Dev\workspace\java_basic\study\src\chapter15\stream\other\newFile.txt
		System.out.println(file.getPath()); // C:\Dev\workspace\java_basic\study\src\chapter15\stream\other\newFile.txt
		System.out.println(file.canRead()); // true
		System.out.println(file.canWrite()); // true
		
		file.delete(); //파일삭제.
		
		File dir = new File("C:\\Dev\\workspace\\java_basic\\study\\src\\chapter15\\stream\\other\\temp\\sub");
		// 경로에 존재하지 않는 폴더는 모두 생성한다.
		dir.mkdirs();  // dir.mkdir() : 현재폴더를 기준하여, 자식폴더 생성

	}

}
