package chapter15.stream.outputstream;

import java.io.FileOutputStream;
import java.io.IOException;

// 출력스트림
public class FileOutputStreamTest1 {

	public static void main(String[] args) {
		
		//출력스트림객체 생성이 되면, 매개변수의 파일이 생성된다.
		try(FileOutputStream fos = new FileOutputStream("output.txt", true)) {
			
			fos.write(65); // A
			fos.write(66); // B
			fos.write(67); // C
		}catch(IOException e) {
			e.printStackTrace();
		}
		System.out.println("출력완료");

	}

}
