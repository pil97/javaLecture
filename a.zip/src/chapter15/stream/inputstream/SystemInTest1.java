package chapter15.stream.inputstream;

import java.io.IOException;

// 표준입출력 : 키보드 또는 모니터를 대상으로 입출력작업을 하는 기능.
public class SystemInTest1 {

	public static void main(String[] args) {
		System.out.println("알파벳 하나를 입력하고, [Enter]를 누르세요.");
		
		int i;
		
		try {
			i = System.in.read(); // 콘솔응용프로그램 개발
			System.out.println(i);
			System.out.println((char)i);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
