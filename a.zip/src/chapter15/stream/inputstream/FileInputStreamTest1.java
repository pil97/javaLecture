package chapter15.stream.inputstream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

// 바이트 단위스트림
public class FileInputStreamTest1 {

	public static void main(String[] args) {

		//데이터소스 : 파일
		FileInputStream fis = null;
		
		try {
			//fis = new FileInputStream("C:\\Dev\\workspace\\java_basic\\study\\src\\chapter15\\stream\\inputstream\\input.txt"); // input.txt 파일이 존재하지 않으면, 예외발생.
			fis = new FileInputStream("input.txt"); // input.txt 파일이 존재하지 않으면, 예외발생.
			
			//fis입력스트림을 통하여, 파일 데이터 읽기작업.
			
			System.out.println((char)fis.read());
			System.out.println((char)fis.read());
			System.out.println((char)fis.read());
		} catch (IOException e) { // 예외관련클래스.  try구문에서 발생한 예외정보를 처리하는 클래스
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				if(fis != null) {
					fis.close();
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("프로그램 종료");

	}

}
