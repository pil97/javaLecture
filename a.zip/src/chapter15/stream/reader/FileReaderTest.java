package chapter15.stream.reader;

import java.io.FileReader;
import java.io.Reader;

// 문자단위 스트림
public class FileReaderTest {

	public static void main(String[] args) {
		
		// Reader : 입력문자스트림. 최상위 추상클래스
		// 텍스트파일의 내용을 쉽게 읽고쓰는 작업을 위하여 제공하는 클래스
		try(Reader fr = new FileReader("reader.txt")) {
			int i;
			// 1개 문자를 읽어들인다.
			while(( i = fr.read()) != -1) {
				System.out.print((char) i);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}

	}

}
