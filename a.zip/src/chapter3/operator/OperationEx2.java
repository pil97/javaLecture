package chapter3.operator;

public class OperationEx2 {

	public static void main(String[] args) {
		// 증감연산자.   ++ or --
		// 변수 앞 또는 뒤에 사용하여, 동작순서가 달라진다.
		
		int gameScore = 150;
		
		// gameScore에 +1을 한값을 저장하여, gameScore변수값을 읽어와서 좌측변수에 대입
		int lastScore1 = ++gameScore; 
		System.out.println(lastScore1); // 151
		
		int lastScore2 = --gameScore; // 150
		System.out.println(lastScore2);
		
		int myAge = 27;
		boolean value = (myAge > 25);
		System.out.println(value);
		
		
		
		

	}

}
