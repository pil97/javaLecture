package chapter3.operator;

public class OperationEx1 {

	public static void main(String[] args) {
		// 산술연산자(+,-,*,/)
		int mathScore = 90;
		int engScore = 75;
		
		int totalScore = mathScore + engScore;
		System.out.println(totalScore);
		
		double avgScore = totalScore / 2.0;  // 2 int형값으로 나누어서는 안된다.
		System.out.println(avgScore);

	}

}
