package chapter3.operator;

public class OperationEx4 {

	public static void main(String[] args) {
		// 조건연산자(삼항연산자) 
		// if~else 구문과 유사한 특징.
		
		int fatherAge = 45;
		int motherAge = 47;
		
		char ch;
		ch = (fatherAge > motherAge) ? 'T':'F';
		
		System.out.println(ch);

	}

}
