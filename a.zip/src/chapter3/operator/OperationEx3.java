package chapter3.operator;

public class OperationEx3 {

	public static void main(String[] args) {
		// 논리연산자.   &&  || !
		
		// 논리연산자.  && or || 사용시 우측의 코드가 항상 실행되는 것은 아니다.(중요)
		
		int num1 = 10;
		int i = 2;
		
		// 좌측 && 우측
		// 좌측이 false이면, 우측이 true or false에 상관없이 결과는 false되는 구조이므로
		// 우측은 코드가 실행되지 않는다.
		boolean value = (num1 = num1 + 10) < 10 && (i = i + 2) < 10;
		System.out.println(value); // false
		System.out.println(num1);  // 20
		System.out.println(i);  // 일반적인 예상은 4로 생각할 수 있으나, && 우측코드가 실행이 안되어 2 값이 출력된다.
		
		// 좌측 || 우측
		// 좌측이 true이면, 우측이 true or false에 상관없이 결과는 true되는 구조이므로
		// 우측은 코드가 실행되지 않는다.
		value = (num1 = num1 + 10) > 10 || (i = i + 2) < 10;
		System.out.println(value); // true
		System.out.println(num1);  // 30
		System.out.println(i);  // 일반적인 예상은 4로 생각할 수 있으나, && 우측코드가 실행이 안되어 2 값이 출력된다.
		
	}

}
