package chapter3.operator;

public class OperationEx5 {

	public static void main(String[] args) {
		// 비트 이동연산자 : 일반적인 개발에서는 사용빈도수가 적다.
		// <<  >> >>>
		
		// 정수형변수 : 10진수(기본), 16진수, 8진수, 2진수 형태로 값을 사용할수가 있다.
		int num = 0B10000101; // 2진수값을 8비트로 표현
		
		System.out.println(num << 2); // num변수의 비트데이타가 좌측 2개씩 이동
		System.out.println(num >> 2); // num변수의 비트데이타가 우측 2개씩 이동
		
		// num변수의 비트데이타가 우측 2개씩 이동. 위의 코드와 차이점은 부호비트와 상관없이 무조건 0으로 채움
		System.out.println(num >>> 2);// num변수의 비트데이타가 우측 2개씩 이동
		System.out.println(num);
		
		num = num << 2;
		System.out.println(num);

	}

}
