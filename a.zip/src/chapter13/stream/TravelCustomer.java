package chapter13.stream;

public class TravelCustomer {

	private String name;
	private int age;
	private int price;
	
	//3개 파라미터를 이용한 생성자
	public TravelCustomer(String name, int age, int price) {
		this.name = name;
		this.age = age;
		this.price = price;
	}
	
	// 3개 getter메서드
	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
	
	public int getPrice() {
		return price;
	}
	
	// toString()재정의 : 3개 필드정보 확인.
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "name: " + name + "age: " + age + "price: " + price;
	}
}
