package chapter13.lambda;

public class LanbdaBasic {

	//메서드
	int add(int x, int y) {
		return x + y;
	}
	
	
	//메서드를 람다식문법표현
	void methodA() {
		
		// add()메서드 표현
//		(int x, int y) -> { return x + y;}
	}
}
