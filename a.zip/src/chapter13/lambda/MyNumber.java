package chapter13.lambda;

//함수형인터페이스 : 추상메서드 1개를 가지고 있는 인터페이스
@FunctionalInterface // @이름 : Annotation(어노테이션)
public interface MyNumber {
	
	// 추상메서드
	int getMax(int num1, int num2);
}
