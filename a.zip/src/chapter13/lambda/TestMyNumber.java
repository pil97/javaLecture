package chapter13.lambda;

//인터페이스를 구현
class Test implements MyNumber {

	// 두 수를 비교하여, 큰값을 리턴하는 목적으로 재정의
	@Override
	public int getMax(int num1, int num2) {
		
		if(num1 > num2) {
			return num1;
		}else {
			return num2;
		}
		
	}
	
}


public class TestMyNumber {

	public static void main(String[] args) {
		//1)
		Test t = new Test();
		t.getMax(10, 20);
		
		
//		2)MyNumber max = 추상메서드 구현작업을 람다식으로 문법표현;
		//인터페이스를 구현하여, 재정의한 의미.
		MyNumber max = (x, y)  -> (x >= y) ? x: y; // 실행문이 한줄이면 return 생략가능
		
		System.out.println(max.getMax(10, 20));

	}

}
