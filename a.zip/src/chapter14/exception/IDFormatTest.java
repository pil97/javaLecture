package chapter14.exception;

// 사용자정의 예외클래스 만들기
// 회사의 업무기능을 구현하다보면 업무처리에 따른 다양한 예외들이 존재할수 있다.
// 그에 따른 업무관련 기능이 동작하다 예외가 발생하면, 처리목적으로 사용하는 예외클래스
// 예> 사용자 아이디정보가 존재하지 않을 때(null) 또는 아이디 길이가 8~20 범위밖이었을 때.
public class IDFormatTest {

	 private String userID;
	 
	 public String getUserID() {
		 return userID;
	 }
	 
	 public void setUserID(String userID) throws IDFormatException {
		 if(userID == null) {
			 //사용자정의 예외클래스
			 throw new IDFormatException("아이디는 null 일 수 없습니다."); //예외발생하는 구문
		 }else if(userID.length() < 8 || userID.length() > 20) {
			 //사용자정의 예외클래스
			 throw new IDFormatException("아이디는 8자이상 20자 이하로 사용가능");
		 }
		 
		 this.userID = userID;
	 }
	
	public static void main(String[] args) {
		
		IDFormatTest test = new IDFormatTest();
		String userID = null;
		
		try {
			test.setUserID(userID);
		} catch (IDFormatException e) {
			System.out.println(e.getMessage());
		}
		
		userID = "1234567";  // 7자리
		
		try {
			test.setUserID(userID);
		} catch (IDFormatException e) {
			System.out.println(e.getMessage());
		}

	}

}
