package chapter14.exception;

// 사용자정의 예외클래스
public class IDFormatException extends Exception {

	// 매개변수가 있는 생성자.
	public IDFormatException(String message) {
		super(message);
	}
}
