package chapter8.polymorphism;

// 동물클래스
// Human, Tiger, Eagle 클래스의 재정의된 move()메서드를 주석을 번갈아가며 실행결과를 확인한다.
// 재정의된 경우에는 자식클래스의 move()메서드가 호출되고,
// 재정의가 안된 경우에는 부모클래스의 move()메서드가 호출되도록 설계를 해두었다.

class Animal {
	public void move() {
		System.out.println("동물이 움직입니다.");
	}
}

class Human extends Animal {

	@Override
	public void move() {
		System.out.println("사람이 두 발로 걷습니다.");
	}
	
	public void readBook() {
		System.out.println("사람이 책을 읽습니다.");
	}
	
}

class Tiger extends Animal {
	@Override
	public void move() {
		System.out.println("호랑이가 네 발로 뜁니다.");
	}
	
	public void hunting() {
		System.out.println("호랑이가 사냥을 합니다.");
	}
}

class Eagle extends Animal {
	@Override
	public void move() {
		System.out.println("독수리가 하늘을 납니다.");
	}
	
	public void flying() {
		System.out.println("독수리가 날개를 쭉 펴고 멀리 날아갑니다.");
	}
}

//추가
class Lion extends Animal {
	
	@Override
	public void move() {
		System.out.println("사자가 사냥을 합니다.");
	}
}

public class AnimalTest1 {
	
	// main()메서드는 AnimalTest1클래스의 멤버로 생각하면 안된다.
	// JVM에의하여 독립적으로 관리되는 실행기능을 담당하는 메서드이다.
	public static void main(String[] args) {
		AnimalTest1 aTest = new AnimalTest1();
		aTest.moveAnimal(new Human());
		aTest.moveAnimal(new Tiger());
		aTest.moveAnimal(new Eagle());
		
		//추가
		aTest.moveAnimal(new Lion());
	}
	
	//매개변수를 통한 다형성 기능특징을 갖고있는 메서드.(중요)
	// 하나의 부모변수가 상대적으로 여러개의 자식객체 특징을 갖게되는 의미.
	//상속과다형성
	public void moveAnimal(Animal animal) {
		//재정의된 메서드 일경우에는 자식객체의 메서드를 호출한다.
		animal.move();
	}
}














