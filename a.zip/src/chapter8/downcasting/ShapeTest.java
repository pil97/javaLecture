package chapter8.downcasting;

// 도형
class Shape {
	void draw() {
		System.out.println("draw Shape");
	}
}

// 원형
class Circle extends Shape {
	@Override
	void draw() {
		System.out.println("draw Circle");
	}
	
	void circle() {
		System.out.println("원 입니다.");
	}
}

// 사각형
class Rectange extends Shape {
	@Override
	void draw() {
		System.out.println("draw Rectange");
	}
	
	void rectange() {
		System.out.println("사각형 입니다.");
	}
}

// 삼각형
class Triangle extends Shape {
	@Override
	void draw() {
		System.out.println("draw Triangle");
	}
	
	void triangle() {
		System.out.println("삼각형입니다.");
	}
}



public class ShapeTest {

	public static void main(String[] args) {
	//1)부모클래스(Shape) 변수로 자식클래스(Circle)객체를 대입받으면. 부모클래스의 모든멤버 접근가능
    //2)부모클래스의 메서드를 자식클래스에서 재정의되었으면, 자식클래스의 메서드가 호출된다.
	//3)자식클래스의 추가메서드를 호출하고 싶으면, 다운캐스팅을 해야 한다.
		Shape shape1 = new Circle();
//		Shape shape1 = new Rectange();
		if(shape1 instanceof Circle) { // shape1변수가 Circle클래스 이면
			// 부모클래스 객체로 자식클래스의 객체에 대입
			// 다운캐스팅
			Circle c = (Circle) shape1; // instanceof 를 사용하는 이유는 다운캐스팅시 에러가 날수 있는 상황을 막기위하여
			c.circle();
			
			Circle c2 = new Circle();
			c2.circle();
		}

	}

}
