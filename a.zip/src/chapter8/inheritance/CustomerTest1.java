package chapter8.inheritance;

public class CustomerTest1 {

	public static void main(String[] args) {
		
		// VIPCustomer 클래스와는 전혀 상관이 없다.
		Customer customerLee = new Customer();
		customerLee.setCustomerID(10010);
		customerLee.setCustomerName("이순신");
		customerLee.bonusPoint = 1000;
		System.out.println(customerLee.showCustomerInfo());
		
		
		System.out.println("=======================================================");
		
		// 자식클래스 VIPCustomer를 이용하여, 객체를 생성시 부모클래스 Customer가 어떻게 동작되어지는 지?
		// new : Customer클래스를 사용하여, 힙영역에 메모리 생성 후 VIPCustomer클래스를 사용하여, 힙영역에 메모리 생성
		// 
		VIPCustomer customerKim = new VIPCustomer();

	}

}
