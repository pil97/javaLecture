package chapter8.inheritance;

// 상속시 클래스간의 형변환(Casting)
public class OverridingTest2 {

	public static void main(String[] args) {
		// 부모클래스 변수로 자식객체를 대입.
		// new VIPCustomer(10030, "나몰라", 2000); 부모클래스 정보를 가지고 힙영역에 메모리생성, 자식클래스 정보를 가지고 힙영역 메모리 생성
		// 타입일치
//		Customer vc =  (Customer )new VIPCustomer(10030, "나몰라", 2000);
		Customer vc = new VIPCustomer(10030, "나몰라", 2000);
		// 부모클래스 변수로 자식객체를 형변환 하면, 부모클래스 멤버만 접근가능(중요)
		// Customer클래스인 vc객체로 접급이 가능한 멤버는 Customer클래스의 멤버만 접근이 가능하다.
		// vc.멤버		 목록확인 요망.
		vc.bonusPoint = 1000;
		
		System.out.println(vc.getCustomerName() + "님이 지불해야 하는 금액은 " + vc.calcPrice(10000) + "원입니다.");

	}

}
