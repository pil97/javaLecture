package chapter8.inheritance;

// 상속 : 기존에 존재하고 있는 클래스를 새로운 클래스를 만들때 재사용목적으로 이용하는 것.
// 접근자 : private < [default] < protected < public  우측방향
// private 접근자는 상속안됨.
// protected 접근자 : 상속 접근자.
// 위의 접근자 설명 : 다른 패키지에서 상속시 public
// 다른 패키지에서 상속이 아닌 그냥 사용할 경우에는 private
// 부모클래스
public class Customer {
	
	protected int customerID;
	protected String customerName;
	protected String customerGrade;
	int bonusPoint;  // 접근자 default
	double bonusRatio; // 접근자 default
	
	// 기본생성자
	public Customer() {
		customerGrade = "SILVER";
		bonusRatio = 0.01;
		System.out.println("Customer() 생성자 호출");
	}

	// 매개변수 있는 생성자
	public Customer(int customerID, String cusotmerName) {
		this.customerID = customerID;
		this.customerName = cusotmerName;
		customerGrade = "SILVER";
		bonusRatio = 0.01;
		
		System.out.println("Customer(int, String) 생성자 호출");
	}
	
	public int calcPrice(int price) {
		System.out.println("Customer.calcPrice");
		bonusPoint += price * bonusRatio;
		return price;
	}
	
	public String showCustomerInfo() {
		return customerName + " 님의 등급은 " + customerGrade + "이며, 보너스 포인트는 " + bonusPoint + "입니다.";
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String cusotmerName) {
		this.customerName = cusotmerName;
	}

	public String getCustomerGrade() {
		return customerGrade;
	}

	public void setCustomerGrade(String customerGrade) {
		this.customerGrade = customerGrade;
	}
	
	
	
	
	
	
	
	
}
